package com.macastil.infrastructure.file;

public class SaveFile {
	
	public void save() {
	 // guardar /app
	}

}
