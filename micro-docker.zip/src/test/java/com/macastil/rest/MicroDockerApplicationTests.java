package com.macastil.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
